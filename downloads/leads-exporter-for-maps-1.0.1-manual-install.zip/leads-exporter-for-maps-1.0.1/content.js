"use strict";(()=>{function D(e,t){if(t){let o=t.match(/(?:phone|tel|电话|☎|📞)[:\s]*([+\d\s().-]{7,20})/i);if(o)return o[1].trim()}if(!e)return"";let s=/(\+?1?\s*[-.]?\s*\(?\d{3}\)?\s*[-.]?\s*\d{3}\s*[-.]?\s*\d{4})/,n=e.match(s);if(n){let o=n[1].replace(/\D/g,"");if(o.length>=7&&o.length<=15)return n[1].trim()}return""}function N(e){if(!e)return"";let t=e.match(/!19s(ChIJ[A-Za-z0-9_-]+)/);if(t)return t[1];let s=e.match(/ftid=(0x[0-9a-f]+:[0-9a-fx]+)/i);if(s)return s[1];let n=e.match(/place_id=([A-Za-z0-9_-]+)/);return n?n[1]:/^ChIJ[A-Za-z0-9_-]+$/.test(e)?e:""}var H="ext-009";var b={intervalMin:800,intervalMax:2e3,distanceMin:300,distanceMax:600,maxStaleRounds:3,timeout:6e4},ie={concurrency:3,fetchTimeout:5e3,maxHtmlSize:200*1024},G=500,le=1440*60*1e3,ce={minExportCount:3,minLeadsPerExport:20,dismissCooldown:10080*60*1e3,maxDismissCount:2};var S="gmaps-leads-exporter-root";var Q=new Set(["ad_activeview","ad_click","ad_exposure","ad_query","ad_reward","adunit_exposure","app_clear_data","app_exception","app_install","app_remove","app_store_refund","app_update","app_upgrade","dynamic_link_app_open","dynamic_link_app_update","dynamic_link_first_open","error","firebase_campaign","firebase_in_app_message_action","firebase_in_app_message_dismiss","firebase_in_app_message_impression","first_open","first_visit","in_app_purchase","notification_dismiss","notification_foreground","notification_open","notification_receive","notification_send","os_update","session_start","user_engagement"]),j=["license_key","licenseKey","api_key","apiKey","token","secret","password","email","customerEmail","profile_url","profileUrl","profile_pic_url","public_email","public_phone_number","public_phone","contact_phone_number","whatsapp_number","biography","bio","username","full_name","fullName"];function B(e){let t=new Set([...j,...e.blockedParamKeys??[]]),s=Promise.resolve();async function n(){let r=await chrome.storage.local.get("growthInstallId");if(r.growthInstallId)return r.growthInstallId;let p=crypto.randomUUID();return await chrome.storage.local.set({growthInstallId:p}),p}async function o(r,p={}){return s=s.catch(()=>{}).then(()=>m(r,p)),s}async function m(r,p={}){d(r);let a=await n(),u={id:crypto.randomUUID(),name:r,product_id:e.productId,install_id:a,created_at:new Date().toISOString(),params:_({ext_id:e.productId,version:e.getVersion(),install_id:a,...e.debugMode?{debug_mode:!0}:{},...p})},y=[...(await chrome.storage.local.get("growthEventQueue")).growthEventQueue??[],u].slice(-e.queueLimit);await chrome.storage.local.set({growthEventQueue:y});try{await g()}catch(I){console.warn("[core-event-tracking] flush failed; event kept in queue",I)}}function d(r){if(Q.has(r))throw new Error(`Reserved GA4 Measurement Protocol event name is not allowed: ${r}`)}async function g(r=e.endpoint){if(!r)return;let a=(await chrome.storage.local.get("growthEventQueue")).growthEventQueue??[];if(a.length===0)return;let u=a.slice(0,e.flushBatchSize),w=await fetch(r,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({events:u})});if(!w.ok)throw new Error(`Core event tracking flush failed: ${w.status}`);await chrome.storage.local.set({growthEventQueue:a.slice(u.length)})}async function h(){return(await chrome.storage.local.get("growthFirstOpenAt")).growthFirstOpenAt?!1:(await chrome.storage.local.set({growthFirstOpenAt:Date.now()}),!0)}function _(r){let p={};for(let[a,u]of Object.entries(r))t.has(a)||u!==void 0&&(typeof u=="string"||typeof u=="number"||typeof u=="boolean"||u===null)&&(p[a]=u);return p}return{trackEvent:o,flushEvents:g,getOrCreateInstallId:n,markExtensionOpen:h}}var k=B({productId:H,endpoint:"",debugMode:!1,queueLimit:200,flushBatchSize:20,getVersion:ee,blockedParamKeys:["query","search_query","place_id","placeId","website"]}),v=k.trackEvent,me=k.flushEvents,_e=k.getOrCreateInstallId,fe=k.markExtensionOpen;function ee(){try{return chrome.runtime?.getManifest?.().version??null}catch{return null}}function V(e){return new Promise(t=>setTimeout(t,e))}function f(...e){console.log("[GLE]",...e)}var A=class{constructor(){this.lastUrl="";this.intervalId=null}start(t){this.lastUrl=location.href,this.intervalId=window.setInterval(()=>{if(location.href!==this.lastUrl){let s=location.href.includes("/maps/search/");this.lastUrl=location.href,s&&(f("SPA navigation detected, reinitializing"),t())}},G)}stop(){this.intervalId!==null&&(clearInterval(this.intervalId),this.intervalId=null)}},O=class{constructor(){this.aborted=!1;this.leads=[];this.seenIds=new Set;this.idCounter=0}async scrollAndCollect(t,s,n){this.aborted=!1,this.leads=[],this.seenIds.clear(),this.idCounter=0;let o=0,m=0,d=Date.now();for(this.parseNewCards(t),s(this.leads.length);!this.aborted;){let g=b.distanceMin+Math.random()*(b.distanceMax-b.distanceMin);t.scrollBy({top:g,behavior:"smooth"});let h=b.intervalMin+Math.random()*(b.intervalMax-b.intervalMin);if(await V(h),this.parseNewCards(t),s(this.leads.length),this.leads.length===m){if(o++,o>=b.maxStaleRounds){f("Stale limit reached, stopping scroll");break}}else o=0,m=this.leads.length;if(Date.now()-d>b.timeout){f("Timeout reached, stopping scroll");break}if(this.leads.length>=120){f("Platform max results reached");break}}n(this.leads)}abort(){this.aborted=!0}getLeads(){return[...this.leads]}parseNewCards(t){let s=t.querySelectorAll('div[role="article"]');for(let n of s){let o=n.querySelector('a[href*="/maps/place/"]');if(!o)continue;let m=o.getAttribute("href")||"",d=N(m);if(d||(d=m),this.seenIds.has(d))continue;this.seenIds.add(d);let g=o.getAttribute("aria-label")||n.getAttribute("aria-label")||"",h=n.querySelector("h1 .jHLihd");h&&h.textContent?.includes("\u8D5E\u52A9");let _=null,r=n.querySelector('span[role="img"][aria-label]');if(r){let c=(r.getAttribute("aria-label")||"").match(/([\d.]+)\s*(?:stars?|星级|颗星)/i);if(c){let l=parseFloat(c[1]);l>=1&&l<=5&&(_=l)}}let p=null,a=n.querySelector(".e4rVHe");if(a){let i=a.parentElement;if(i){let l=(i.textContent||"").match(/\(([\d,]+)\)/);l&&(p=parseInt(l[1].replace(/,/g,""),10))}}if(p===null){let i=n.querySelectorAll("[aria-label]");for(let c of i){let E=(c.getAttribute("aria-label")||"").match(/([\d,]+)\s*(?:reviews?|条评价|评论)/i);if(E){p=parseInt(E[1].replace(/,/g,""),10);break}}}let u="",w=n.querySelectorAll(".W4Efsd");for(let i of w){let c=i.querySelectorAll(":scope > div > span > span, :scope > span > span");for(let l of c){let E=l.textContent?.trim()||"";if(!(!E||E==="\xB7")&&!/^\d/.test(E)&&!/营业|Open|Closed|小时/i.test(E)&&!/\(\d{3}\)/.test(E)&&E.length<50&&!/\d{3,}/.test(E)){u=E;break}}if(u)break}let y="",I=n.querySelectorAll("span");for(let i of I){let c=i.textContent?.trim()||"";if(!(!c||c==="\xB7"||c.startsWith("\xB7"))&&/\d{1,6}\s+\w+/.test(c)&&/(?:st|ave|blvd|rd|dr|ln|ct|hwy|street|avenue|road|drive|way|pl|pkwy)\b/i.test(c)&&c.length<100){y=c;break}}if(!y)for(let i of I){let c=i.textContent?.trim()||"";if(c.startsWith("\xB7 ")&&/\d/.test(c)){let l=c.replace(/^·\s*/,"");if(l.length<100&&!/营业|Open|Closed|小时|\(\d{3}\)/i.test(l)){y=l;break}}}let T="",P=n.querySelector("span.UsdlK");if(P&&(T=P.textContent?.trim()||""),!T){let i=n.textContent||"";T=D(i)}let C="",L=n.querySelector('a[aria-label*="\u7F51\u7AD9"], a[aria-label*="website" i]');if(L){let i=L.getAttribute("href")||"";if(i&&!i.includes("/aclk")&&!i.includes("google.com/maps")&&!i.startsWith("/")&&(i.startsWith("http://")||i.startsWith("https://")))C=i;else if(i.includes("google.com/aclk")){let l=(L.getAttribute("aria-label")||"").match(/(?:访问网站|visit\s+website)[·\s]*([\w.-]+\.\w+)/i);l&&(C=l[1])}}if(!C){let i=n.querySelectorAll("a[href]");for(let c of i){let l=c.getAttribute("href")||"";if(l&&!l.includes("google.com")&&!l.includes("gstatic.com")&&(l.startsWith("http://")||l.startsWith("https://"))){C=l;break}}}let R={id:d||`synth-${++this.idCounter}`,name:g,address:y,phone:T,website:C,rating:_,reviewCount:p,category:u,email:"",contactPageUrl:"",emailStatus:"pending",socialLinks:{facebook:"",instagram:"",twitter:"",linkedin:""}};R.name&&this.leads.push(R)}}};function te(){if(document.getElementById(S)){let _=document.getElementById(S);_&&_.remove()}let e=document.createElement("div");e.id=S,e.style.cssText="position:fixed;bottom:0;left:0;right:0;z-index:99999;pointer-events:auto;";let t=e.attachShadow({mode:"open"});t.innerHTML=`
    <style>
      :host {
        all: initial;
        font-family: 'Google Sans', Roboto, Arial, sans-serif;
        display: block;
      }
      .toolbar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 8px 16px;
        background: #fff;
        border-top: 2px solid #1a73e8;
        box-shadow: 0 -2px 8px rgba(0,0,0,0.1);
        gap: 12px;
      }
      .btn {
        padding: 8px 16px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 14px;
        font-weight: 500;
        white-space: nowrap;
        transition: background 0.2s;
      }
      .btn:focus-visible {
        outline: 2px solid #1a73e8;
        outline-offset: 2px;
      }
      .btn-primary { background: #1a73e8; color: #fff; }
      .btn-primary:hover { background: #1557b0; }
      .btn-stop { background: #ea4335; color: #fff; }
      .btn-stop:hover { background: #c5221f; }
      .btn-export { background: #34a853; color: #fff; }
      .btn-export:hover { background: #1e8e3e; }
      .btn:disabled {
        opacity: 0.5;
        cursor: not-allowed;
      }
      .progress {
        flex: 1;
        min-width: 120px;
      }
      .status {
        font-size: 13px;
        color: #5f6368;
        margin-bottom: 4px;
      }
      .progress-bar {
        height: 4px;
        background: #e0e0e0;
        border-radius: 2px;
        overflow: hidden;
      }
      .progress-fill {
        height: 100%;
        background: #1a73e8;
        border-radius: 2px;
        transition: width 0.3s ease;
        width: 0%;
      }
      .quota {
        font-size: 12px;
        color: #80868b;
        white-space: nowrap;
      }
    </style>
    <div class="toolbar" role="toolbar" aria-label="Leads Exporter Controls">
      <button class="btn btn-primary" id="gle-start" type="button">Export All Leads</button>
      <div class="progress" id="gle-progress-wrap" style="display:none">
        <div class="status" id="gle-status">Scanning...</div>
        <div class="progress-bar">
          <div class="progress-fill" id="gle-progress" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
        </div>
      </div>
      <button class="btn btn-stop" id="gle-stop" type="button" style="display:none">Stop</button>
      <button class="btn btn-export" id="gle-export" type="button" style="display:none">Export CSV</button>
      <div class="quota" id="gle-quota"></div>
    </div>
  `,document.body.appendChild(e);let s=t.getElementById("gle-start"),n=t.getElementById("gle-stop"),o=t.getElementById("gle-export"),m=t.getElementById("gle-progress-wrap"),d=t.getElementById("gle-status"),g=t.getElementById("gle-progress"),h=t.getElementById("gle-quota");return!s||!n||!o||!m||!d||!g||!h?(f("Failed to find toolbar elements"),null):{shadow:t,startBtn:s,stopBtn:n,exportBtn:o,progressWrap:m,statusEl:d,progressFill:g,quotaEl:h}}function z(e){return chrome.runtime.sendMessage(e)}async function U(e){try{await chrome.storage.local.set({leads_data:e}),await z({action:"updateBadge",count:e.length}),f(`Stored ${e.length} leads`)}catch(t){f("Error storing leads:",t)}}function K(){return document.querySelector('div.m6QErb[role="main"] div[role="feed"]')||document.querySelector('div[role="feed"]')}async function ne(e=1e4){let t=Date.now();for(;Date.now()-t<e;){let s=K();if(s)return s;await V(500)}return null}function q(){let e=document.querySelector("input#searchboxinput");if(e?.value)return e.value.trim();let t=location.href.match(/\/maps\/search\/([^/]+)/);if(t)try{return decodeURIComponent(t[1].replace(/\+/g," ")).trim()}catch{return t[1].replace(/\+/g," ").trim()}return""}var x=null,W=null;function re(){x&&(x.abort(),x=null);let e=document.getElementById(S);e&&e.remove()}async function F(){re(),await ne()?v("target_detected",{target_type:"google_maps_search_results",surface:"content",source_surface:"google_maps",mode:"search_page"}):f("Feed element not found, toolbar will still be injected");let t=te();if(!t){f("Toolbar injection failed");return}let{startBtn:s,stopBtn:n,exportBtn:o,progressWrap:m,statusEl:d,progressFill:g,quotaEl:h}=t;oe(h);let _=[];s.addEventListener("click",async()=>{let r=K();if(!r){d.textContent="No search results found. Try searching first.",m.style.display="",v("core_task_failed",{task_type:"gmaps_leads_scan",surface:"content",source_surface:"google_maps_toolbar",target_type:"google_maps_search_results",error_type:"target_missing",recoverable:!0});return}s.style.display="none",n.style.display="",o.style.display="none",m.style.display="",d.textContent="Scanning...",g.style.width="0%",x=new O;let p=Date.now();await v("core_task_started",{task_type:"gmaps_leads_scan",surface:"content",source_surface:"google_maps_toolbar",target_type:"google_maps_search_results",mode:"auto_scroll",has_query:!!q()});try{await x.scrollAndCollect(r,a=>{d.textContent=`Found ${a} lead${a!==1?"s":""}...`;let u=Math.min(a/120*100,100);g.style.width=`${u}%`,g.setAttribute("aria-valuenow",String(Math.round(u)))},a=>{_=a,n.style.display="none",o.style.display="",s.style.display="",s.textContent="Scan Again",d.textContent=`Done! ${a.length} lead${a.length!==1?"s":""} found.`,g.style.width="100%",g.setAttribute("aria-valuenow","100"),v("core_task_completed",{task_type:"gmaps_leads_scan",surface:"content",source_surface:"google_maps_toolbar",target_type:"google_maps_search_results",result_count:a.length,duration_sec:Math.round((Date.now()-p)/1e3),reason:a.length>0?"completed":"no_results"}),U(a)})}catch(a){throw v("core_task_failed",{task_type:"gmaps_leads_scan",surface:"content",source_surface:"google_maps_toolbar",target_type:"google_maps_search_results",error_type:"scan_failed",recoverable:!0}),a}}),n.addEventListener("click",()=>{if(x){x.abort();let r=x.getLeads();_=r,n.style.display="none",o.style.display=r.length>0?"":"none",s.style.display="",s.textContent="Scan Again",d.textContent=`Stopped. ${r.length} lead${r.length!==1?"s":""} found.`,r.length>0?(v("core_task_completed",{task_type:"gmaps_leads_scan",surface:"content",source_surface:"google_maps_toolbar",target_type:"google_maps_search_results",result_count:r.length,reason:"stopped_with_results"}),U(r)):v("core_task_failed",{task_type:"gmaps_leads_scan",surface:"content",source_surface:"google_maps_toolbar",target_type:"google_maps_search_results",error_type:"stopped_without_results",recoverable:!0})}}),o.addEventListener("click",async()=>{if(_.length===0)return;let r=q();try{o.disabled=!0,o.textContent="Exporting...",await z({action:"exportCSV",leads:_,query:r}),o.textContent="Export CSV",o.disabled=!1,d.textContent=`Exported ${_.length} leads as CSV.`}catch(p){f("Export error:",p),v("core_task_failed",{task_type:"gmaps_leads_export",surface:"content",source_surface:"google_maps_toolbar",target_type:"google_maps_search_results",error_type:"download_failed",recoverable:!0}),o.textContent="Export CSV",o.disabled=!1,d.textContent="Export failed. Try again."}})}async function oe(e){try{let t=await chrome.storage.local.get(["quota_date","quota_used"]),s=new Date().toISOString().split("T")[0],n=t.quota_date===s&&t.quota_used||0,o=Math.max(50-n,0);e.textContent=`${o}/${50} free today`}catch{e.textContent=`${50} free/day`}}function se(){f("Content Script loaded"),W=new A,W.start(()=>{f("SPA navigation to search page"),F()}),location.href.includes("/maps/search/")?F():f("Not a search page, waiting for navigation")}se();})();
